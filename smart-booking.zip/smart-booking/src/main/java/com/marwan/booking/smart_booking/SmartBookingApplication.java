package com.marwan.booking.smart_booking;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmartBookingApplication {

	public static void main(String[] args) {
		SpringApplication.run(SmartBookingApplication.class, args);
	}

}
