package com.marwan.booking.smart_booking;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SmartBookingApplicationTests {

	@Test
	void contextLoads() {
	}

}
